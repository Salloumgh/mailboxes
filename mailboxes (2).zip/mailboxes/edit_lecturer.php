<!-- edit_lecturer.php -->
<!DOCTYPE html>
<html>
<head>
    <title>עריכת מרצה</title>
</head>
<body>
    <h1>עריכת מרצה</h1>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = ""; // יש למלא סיסמה אם קיימת
    $dbname = "college_mailboxes";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $lecturer_id = $_GET["id"];

        $sql = "SELECT * FROM lecturers WHERE id = $lecturer_id";
        $result = $conn->query($sql);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            echo '<form action="update_lecturer.php" method="post">';
            echo '<input type="hidden" name="id" value="' . $row["id"] . '">';
            echo 'שם המרצה: <input type="text" name="lecturer_name" value="' . $row["lecturer_name"] . '" required><br>';
            echo 'מספר תיבה: <input type="number" name="mailbox_number" value="' . $row["mailbox_number"] . '" required><br>';
            echo 'מספר טלפון: <input type="text" name="phone_number" value="' . $row["phone_number"] . '" required><br>';
            echo '<input type="submit" value="שמור עדכון">';
            echo '</form>';
        } else {
            echo "מרצה לא נמצא";
        }
    }
    $conn->close();
    ?>
</body>
</html>
