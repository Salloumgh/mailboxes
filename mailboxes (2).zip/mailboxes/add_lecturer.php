<!-- add_lecturer.php -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lecturer_name = $_POST["lecturer_name"];
    $mailbox_number = $_POST["mailbox_number"];
    $phone_number = $_POST["phone_number"];

    $servername = "localhost";
    $username = "root";
    $password = ""; // יש למלא סיסמה אם קיימת
    $dbname = "college_mailboxes";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO lecturers (lecturer_name, mailbox_number, phone_number) VALUES ('$lecturer_name', $mailbox_number, '$phone_number')";

    if ($conn->query($sql) === TRUE) {
        echo "המרצה התווסף בהצלחה";
    } else {
        echo "שגיאה בהוספת המרצה: " . $conn->error;
    }

    $conn->close();
}
?>
