<!-- lecturers.php -->
<!DOCTYPE html>
<html>
<head>
    <title>ניהול מרצים</title>
</head>
<body>
    <h1>ניהול מרצים</h1>
    <form action="add_lecturer.php" method="post">
        <label for="lecturer_name">שם המרצה:</label>
        <input type="text" name="lecturer_name" required><br>

        <label for="mailbox_number">מספר תיבה:</label>
        <input type="number" name="mailbox_number" required><br>

        <label for="phone_number">מספר טלפון:</label>
        <input type="text" name="phone_number" required><br>

        <input type="submit" value="הוסף מרצה">
    </form>

    <h2>רשימת המרצים:</h2>
    <table>
        <thead>
            <tr>
                <th>שם מרצה</th>
                <th>מספר תיבה</th>
                <th>מספר טלפון</th>
                <th>פעולות</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // PHP code to fetch and display lecturers from the database
            $servername = "localhost";
            $username = "root";
            $password = ""; // יש למלא סיסמה אם קיימת
            $dbname = "college_mailboxes";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM lecturers";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["lecturer_name"] . "</td>";
                    echo "<td>" . $row["mailbox_number"] . "</td>";
                    echo "<td>" . $row["phone_number"] . "</td>";
                    echo '<td><a href="edit_lecturer.php?id=' . $row["id"] . '">עריכה</a> | <a href="delete_lecturer.php?id=' . $row["id"] . '">מחיקה</a></td>';
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>לא נמצאו מרצים במערכת</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>
