<!-- delete_lecturer.php -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $lecturer_id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $password = ""; // יש למלא סיסמה אם קיימת
    $dbname = "college_mailboxes";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "DELETE FROM lecturers WHERE id = $lecturer_id";

    if ($conn->query($sql) === TRUE) {
        echo "המרצה נמחק בהצלחה";
    } else {
        echo "שגיאה במחיקת המרצה: " . $conn->error;
    }

    $conn->close();
}
?>
