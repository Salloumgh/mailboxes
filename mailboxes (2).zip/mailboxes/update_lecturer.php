<!-- update_lecturer.php -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lecturer_id = $_POST["id"];
    $lecturer_name = $_POST["lecturer_name"];
    $mailbox_number = $_POST["mailbox_number"];
    $phone_number = $_POST["phone_number"];

    $servername = "localhost";
    $username = "root";
    $password = ""; // יש למלא סיסמה אם קיימת
    $dbname = "college_mailboxes";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE lecturers SET lecturer_name = '$lecturer_name', mailbox_number = $mailbox_number, phone_number = '$phone_number' WHERE id = $lecturer_id";

    if ($conn->query($sql) === TRUE) {
        echo "המרצה עודכן בהצלחה";
    } else {
        echo "שגיאה בעדכון המרצה: " . $conn->error;
    }

    $conn->close();
}
?>
