// create_table.php
<?php
$servername = "localhost";
$username = "root";
$password = ""; // יש למלא סיסמה אם קיימת
$dbname = "college_mailboxes";

// יצירת חיבור למסד הנתונים
$conn = new mysqli($servername, $username, $password, $dbname);

// בדיקת החיבור
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// יצירת טבלה לנתוני המרצים
$sql = "CREATE TABLE IF NOT EXISTS lecturers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lecturer_name VARCHAR(255) NOT NULL,
    mailbox_number INT NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'lecturers' created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// סגירת חיבור למסד הנתונים
$conn->close();
?>
