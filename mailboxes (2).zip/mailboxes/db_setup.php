<?php
$servername = "localhost";
$username = "root";
$password = ""; // יש למלא סיסמה אם קיימת
$dbname = "college_mailboxes";

// יצירת חיבור לשרת ה-MYSQL
$conn = new mysqli($servername, $username, $password);

// בדיקת החיבור
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// יצירת מסד הנתונים אם אינו קיים
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

// סגירת חיבור לשרת ה-MYSQL
$conn->close();
?>